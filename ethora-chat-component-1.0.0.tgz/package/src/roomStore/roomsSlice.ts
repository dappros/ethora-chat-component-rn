import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit';
import {
  AddRoomMessageAction,
  ApiRoom,
  EditAction,
  IMessage,
  IRoom,
  ReactionAction,
  RoomMember,
} from '../types/types';
import { insertMessageWithDelimiter } from '../helpers/insertMessageWithDelimiter';
import XmppClient from '../networking/xmppClient';
import { createUserNameFromSetUser } from '../helpers/createUserNameFromSetUser';
import { extractUniqueMembersFromRooms } from '../helpers/extractUniqueMembersFromRooms';

interface RoomMessagesState {
  rooms: { [jid: string]: IRoom };
  activeRoomJID: string | null;
  editAction?: EditAction;
  isLoading: boolean;
  usersSet: Record<string, RoomMember>;
  reportRoom: {
    isOpen: boolean;
  };
  loadingText?: string;
}

const initialState: RoomMessagesState = {
  rooms: {},
  activeRoomJID: null,
  isLoading: false,
  editAction: {
    isEdit: false,
    roomJid: '',
    messageId: '',
    text: '',
  },
  usersSet: {},
  reportRoom: {
    isOpen: false,
  },
  loadingText: undefined,
};

export const addRoomViaApi = createAsyncThunk(
  'roomMessages/addRoomViaApi',
  async (
    { room, xmpp }: { room: IRoom; xmpp: XmppClient },
    { dispatch, getState }
  ) => {
    const state = getState() as { rooms: RoomMessagesState };
    const isRoomAlreadyAdded = Object.values(state.rooms.rooms).some(
      (element) => element.jid === room?.jid
    );

    if (!isRoomAlreadyAdded) {
      if (room.jid) {
        xmpp.presenceInRoomStanza(room.jid);
        xmpp?.getHistoryStanza(room.jid, 10);
      }
    }
    
    dispatch(roomsStore.actions.addRoomFromApi({ room }));
  }
);

export const roomsStore = createSlice({
  name: 'roomMessages',
  initialState,
  reducers: {
    addRoom(state, action: PayloadAction<{ roomData: IRoom }>) {
      const { roomData } = action.payload;
      state.rooms[roomData.jid] = roomData;
    },
    deleteRoom(state, action: PayloadAction<{ jid: string }>) {
      const { jid } = action.payload;
      if (state.rooms[jid]) {
        delete state.rooms[jid];
      }
    },
    updateRoom(
      state,
      action: PayloadAction<{ jid: string; updates: Partial<IRoom> }>
    ) {
      const { jid, updates } = action.payload;
      const existingRoom = state.rooms[jid];

      if (existingRoom) {
        state.rooms[jid] = {
          ...existingRoom,
          ...updates,
        };
      }
    },
    setRoomMessages(
      state,
      action: PayloadAction<{ roomJID: string; messages: IMessage[] }>
    ) {
      const { roomJID, messages } = action.payload;
      if (state.rooms[roomJID]) {
        state.rooms[roomJID].messages = messages;
      }
    },
    deleteRoomMessage(
      state,
      action: PayloadAction<{ roomJID: string; messageId: string }>
    ) {
      const { roomJID, messageId } = action.payload;
      if (state.rooms[roomJID]) {
        state.rooms[roomJID].messages = state.rooms[roomJID].messages.filter(
          (message) => message.id !== messageId
        );
      }
    },
    setReactions: (
      state,
      action: PayloadAction<ReactionAction | undefined>
    ) => {
      if(!action.payload) return;

      const { roomJID, messageId, reactions, from, data } = action.payload;

      if (state.rooms[roomJID]) {
        state.rooms[roomJID].messages.map((message) => {
          if (message.id === messageId) {
            if (from) {
              if (!message.reaction) {
                message.reaction = {};
              }

              const fromId = from.split('@')[0];
              if (reactions.length === 0) {
                delete message.reaction[fromId];
              } else {
                message.reaction[fromId] = {
                  emoji: reactions,
                  data: data,
                };
              }
            }
          }
        });
      }
    },
    setEditAction: (state, action: PayloadAction<EditAction | undefined>) => {
      if(!action.payload) return;
      
      const { isEdit } = action.payload;
      if (isEdit) {
        state.editAction = action.payload;
      } else {
        state.editAction = {
          isEdit: false,
          roomJid: '',
          messageId: '',
          text: '',
        };
      }
    },
    editRoomMessage(
      state,
      action: PayloadAction<{
        roomJID: string;
        messageId: string;
        text: string;
      }>
    ) {
      const { roomJID, messageId, text } = action.payload;
      if (state.rooms[roomJID]) {
        state.rooms[roomJID].messages.map((message) => {
          if (message.id === messageId) {
            message.body = text;
          }
        });
      }
    },
    addRoomMessage(state, action: PayloadAction<AddRoomMessageAction>) {
      const { roomJID, message, start } = action.payload;

      console.log('addRoomMessage', { roomJID, message, start });

      if (!message?.body) return;

      const roomMessages = state.rooms[roomJID]?.messages;

      const roomsExist =
        Object.keys(JSON.parse(JSON.stringify(state.rooms))).length > 0;

      const roomExist = !!state?.rooms[roomJID];
      if (!roomsExist || !roomExist) {
        return;
      }

      if (!roomMessages) {
        state.rooms[roomJID].messages = [];
      }

      const existingIndex = roomMessages.findIndex(
        (msg) =>
          msg.id === message.id ||
          (message.xmppId && msg.id === message.xmppId) ||
          (msg.xmppId && msg.xmppId === message.id)
      );
      
      if (existingIndex !== -1) {
        roomMessages[existingIndex] = deepMerge(
          { ...roomMessages[existingIndex] },
          { ...message, pending: false }
        );
        return;
      }

      const updMessage = {
        ...message,
        user: {
          name: createUserNameFromSetUser(state.usersSet, message.user.id),
          ...message.user,
        },
      };

      if (roomMessages.length === 0 || start) {
        const index = roomMessages.findIndex(
          (msg) => msg.id === message.xmppId || msg.id === message.id
        );
        if (index !== -1) {
          roomMessages[index] = {
            ...updMessage,
            id: updMessage.id,
            pending: false,
          };
        } else {
          roomMessages.unshift(updMessage);
        }
      } else {
        const lastViewedTimestamp = state.rooms[roomJID].lastViewedTimestamp
          ? new Date(state.rooms[roomJID].lastViewedTimestamp)
          : null;

        insertMessageWithDelimiter(
          roomMessages,
          updMessage,
          lastViewedTimestamp
        );
      }
    },
    deleteAllRooms(state) {
      state.rooms = {};
    },
    insertUsers(state, action: PayloadAction<{ newUsers: RoomMember[] }>) {
      const { newUsers } = action.payload;
      if (!newUsers || newUsers.length === 0) return;

      newUsers.forEach((user) => {
        state.usersSet[user.xmppUsername] = user;
      });
    },
    setComposing(
      state,
      action: PayloadAction<{
        chatJID: string;
        composing: boolean;
        composingList?: string[];
      }>
    ) {
      const { chatJID, composing, composingList } = action.payload;
      
      if (!state.rooms[chatJID]) {
        return;
      }

      state.rooms[chatJID].composing = composing;
      state.rooms[chatJID].composingList = composingList;
    },
    setIsLoading: (
      state,
      action: PayloadAction<{
        chatJID?: string;
        loading: boolean;
        loadingText?: string;
      }>
    ) => {
      const { chatJID, loading, loadingText } = action.payload;
      if (chatJID && state.rooms?.[chatJID]) {
        state.rooms[chatJID].isLoading = loading;
      }
      if (!chatJID) {
        state.isLoading = loading;
      }
      if (loadingText) {
        state.loadingText = loadingText;
      }
    },
    setLastViewedTimestamp: (
      state,
      action: PayloadAction<{ chatJID: string; timestamp: number }>
    ) => {
      const { chatJID, timestamp } = action.payload;
      if (state.rooms[chatJID]) {
        state.rooms[chatJID].lastViewedTimestamp = timestamp;
        if (timestamp) {
          state.rooms[chatJID].unreadMessages = countNewerMessages(
            state.rooms[chatJID].messages,
            timestamp
          );
        }
      }
    },
    setRoomRole: (
      state,
      action: PayloadAction<{ chatJID: string; role: string }>
    ) => {
      const { chatJID, role } = action.payload;
      if (state.rooms[chatJID]) {
        state.rooms[chatJID].role = role;
      }
    },
    setRoomNoMessages: (
      state,
      action: PayloadAction<{ value: boolean; chatJID?: string }>
    ) => {
      const { value, chatJID } = action.payload;
      if (chatJID) {
        state.rooms[chatJID].noMessages = value;
      }
    },
    setCurrentRoom: (
      state,
      action: PayloadAction<{ roomJID: string | null }>
    ) => {
      const { roomJID } = action.payload;
      state.activeRoomJID = roomJID;
    },
    setLogoutState: (state) => {
      state.rooms = {};
      state.activeRoomJID = null;
      state.isLoading = false;
      state.usersSet = {};
    },
    setActiveMessage: (
      state,
      action: PayloadAction<{ id: string; chatJID: string }>
    ) => {
      const { id, chatJID } = action.payload;

      state.rooms[chatJID].messages.map((message) => {
        if (message.id === id) {
          message.activeMessage = true;
        } else {
          message.activeMessage = false;
        }
      });
    },
    setCloseActiveMessage: (
      state,
      action: PayloadAction<{ chatJID: string }>
    ) => {
      const { chatJID } = action.payload;

      state.rooms[chatJID].messages.map((message) => {
        message.activeMessage = false;
      });
    },
    addRoomFromApi: (state, action: PayloadAction<{ room: IRoom }>) => {
      const { room } = action.payload;
      const existingRoom = state.rooms[room.jid];
      
      if (existingRoom) {
        const preservedUnreadMessages = existingRoom.unreadMessages ?? 0;
        const preservedLastViewedTimestamp = existingRoom.lastViewedTimestamp ?? 0;
        const preservedMessages = existingRoom.messages?.length > 0 
          ? existingRoom.messages 
          : room.messages;
        
        state.rooms[room.jid] = {
          ...room,
          unreadMessages: preservedUnreadMessages,
          lastViewedTimestamp: preservedLastViewedTimestamp,
          messages: preservedMessages,
        };
        
        if (preservedLastViewedTimestamp > 0 && preservedMessages.length > 0) {
          state.rooms[room.jid].unreadMessages = countNewerMessages(
            preservedMessages,
            preservedLastViewedTimestamp
          );
        }
      } else {
        state.rooms[room.jid] = room;
      }
    },
    updateUsersSet: (state, action: PayloadAction<{ rooms: ApiRoom[] }>) => {
      const { rooms } = action.payload;
      state.usersSet = extractUniqueMembersFromRooms(rooms).object;
    },
    setOpenReportModal: (state, action: PayloadAction<{ isOpen: boolean }>) => {
      state.reportRoom.isOpen = action.payload.isOpen;
    },
  },
});

function deepMerge(target: any, source: any): any {
  for (const key in source) {
    if (
      source[key] &&
      typeof source[key] === 'object' &&
      !Array.isArray(source[key])
    ) {
      target[key] = deepMerge(target[key] || {}, source[key]);
    } else {
      target[key] = source[key];
    }
  }
  return target;
}

const countNewerMessages = (
  messages: IMessage[],
  timestamp: number
): number => {
  if (timestamp !== 0 && messages && messages.length > 0) {
    return messages.filter((message) => {
      if (message.id === 'delimiter-new') {
        return false;
      }
      const messageDate = new Date(message.date).getTime();
      return messageDate > timestamp;
    }).length;
  } else return 0;
};

export const getLastMessageTimestamp = (
  state: RoomMessagesState,
  jid: string
): string | null => {
  const room = state.rooms[jid];
  if (!room || room.messages.length === 0) {
    return null;
  }
  const lastMessage = room.messages[room.messages.length - 1];
  return lastMessage.id;
};

export const {
  addRoom,
  deleteAllRooms,
  setRoomMessages,
  addRoomMessage,
  deleteRoomMessage,
  setEditAction,
  editRoomMessage,
  setComposing,
  setIsLoading,
  setLastViewedTimestamp,
  setRoomNoMessages,
  setCurrentRoom,
  setRoomRole,
  setReactions,
  setLogoutState,
  setActiveMessage,
  setCloseActiveMessage,
  deleteRoom,
  updateRoom,
  updateUsersSet,
  setOpenReportModal,
  insertUsers,
} = roomsStore.actions;

export default roomsStore.reducer;

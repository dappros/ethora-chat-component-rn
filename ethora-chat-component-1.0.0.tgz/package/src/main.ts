import 'react-native-get-random-values';

// Main component
export { ReduxWrapper as Chat } from './components/MainComponents/ReduxWrapper';

// Provider
export { XmppProvider } from './context/xmppProvider';

// Hooks
export { useUnread } from './hooks/useUnreadMessagesCounter';
export { useLogout } from './hooks/useLogout';
export { useQRCodeChat, handleQRChatId } from './hooks/useQRCodeChatHandler';

// Services
export { logoutService } from './hooks/useLogout';

// Utils
export { resendMessage } from './utils/resendMessage';

// Types
export * from './types/types';

// Redux hooks (for advanced usage)
export { useAppDispatch, useAppSelector } from './hooks/hooks';


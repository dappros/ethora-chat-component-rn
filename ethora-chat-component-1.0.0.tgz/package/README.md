# @ethora/chat-component

React Native chat component with XMPP support for both **Expo** and **React Native CLI** projects.

## Features

- 💬 Real-time messaging with XMPP
- 📱 Cross-platform (iOS & Android)
- 🎨 Customizable UI components
- 🔐 Secure authentication
- 📸 Media sharing (images, videos, files, audio)
- 🔔 Push notifications support
- 🌐 Multi-language support
- 🎯 TypeScript support

## Installation

### For React Native CLI Projects

```bash
npm install @ethora/chat-component
# or
yarn add @ethora/chat-component
```

### For Expo Projects

> **Note**: This library requires **Expo Dev Client** (development build). It does not work with standard Expo Go.

```bash
# Install the package
npm install @ethora/chat-component

# Install Expo Dev Client
npx expo install expo-dev-client

# Add the plugin to app.json or app.config.js
```

#### Configure app.json (Expo)

```json
{
  "expo": {
    "plugins": [
      "@ethora/chat-component"
    ]
  }
}
```

Then run:

```bash
# For iOS
npx expo prebuild --platform ios
npx expo run:ios

# For Android
npx expo prebuild --platform android
npx expo run:android
```

## Usage

### Basic Example

```tsx
import React from 'react';
import { Chat } from '@ethora/chat-component';
import type { IConfig } from '@ethora/chat-component';

const config: IConfig = {
  apiURL: 'https://api.example.com',
  xmppSettings: {
    service: 'xmpp.example.com',
    domain: 'example.com',
    conference: 'conference.example.com',
  },
  colors: {
    primary: '#007AFF',
  },
};

function App() {
  return (
    <Chat
      config={config}
      user={{
        xmppUsername: 'user@example.com',
        xmppPassword: 'password',
        firstName: 'John',
        lastName: 'Doe',
        walletAddress: '0x...',
      }}
    />
  );
}

export default App;
```

### With Login

```tsx
import React from 'react';
import { Chat } from '@ethora/chat-component';

function App() {
  return (
    <Chat
      config={config}
      loginData={{
        email: 'user@example.com',
        password: 'password',
      }}
    />
  );
}
```

### Using Hooks

```tsx
import React from 'react';
import { useUnread, useLogout, useQRCodeChat } from '@ethora/chat-component';

function MyComponent() {
  const { totalCount, hasUnread, unreadByRoom } = useUnread();
  const handleLogout = useLogout();
  const { wasAutoSelected } = useQRCodeChat(
    (params) => console.log('Room selected:', params),
    'conference.example.com'
  );

  return (
    <View>
      <Text>Unread messages: {totalCount}</Text>
      <Button onPress={handleLogout} title="Logout" />
    </View>
  );
}
```

## API Reference

### Components

#### `<Chat />`

Main chat component.

**Props:**

- `config?: IConfig` - Configuration object
- `user?: ConfigUser` - User object (if already authenticated)
- `loginData?: { email: string; password: string }` - Login credentials
- `token?: string` - Authentication token
- `roomJID?: string` - Initial room JID to open
- `MainComponentStyles?: ViewStyle` - Custom styles for main container
- `CustomMessageComponent?: React.ComponentType<MessageProps>` - Custom message component

### Hooks

#### `useUnread()`

Returns unread messages statistics.

```tsx
const { totalCount, hasUnread, unreadByRoom } = useUnread();
```

#### `useLogout()`

Returns logout function.

```tsx
const handleLogout = useLogout();
```

#### `useQRCodeChat(setCurrentRoom, conferenceServer?)`

Handles QR code chat selection.

```tsx
const { wasAutoSelected } = useQRCodeChat(
  (params) => setCurrentRoom(params),
  'conference.example.com'
);
```

### Services

#### `logoutService`

Service for programmatic logout.

```tsx
import { logoutService } from '@ethora/chat-component';

logoutService.performLogout();
```

### Utilities

#### `resendMessage(message, options?)`

Resend a message.

```tsx
import { resendMessage } from '@ethora/chat-component';

await resendMessage({
  body: 'Hello!',
  roomJid: 'room@conference.example.com',
});
```

## Configuration

### IConfig Interface

```typescript
interface IConfig {
  apiURL: string;
  xmppSettings: {
    service: string;
    domain: string;
    conference: string;
  };
  colors?: {
    primary?: string;
    secondary?: string;
  };
  disableRooms?: boolean;
  enableRoomsRetry?: {
    enabled: boolean;
    helperText?: string;
  };
  translates?: {
    enabled: boolean;
    defaultLanguage?: string;
  };
  // ... more options
}
```

## Requirements

- React >= 18.0.0
- React Native >= 0.70.0
- For Expo: Expo SDK 49+ with Expo Dev Client

## Permissions

The library requires the following permissions:

### iOS
- Camera (`NSCameraUsageDescription`)
- Photo Library (`NSPhotoLibraryUsageDescription`)
- Microphone (`NSMicrophoneUsageDescription`)

### Android
- `CAMERA`
- `RECORD_AUDIO`
- `READ_EXTERNAL_STORAGE`
- `WRITE_EXTERNAL_STORAGE`
- `READ_MEDIA_IMAGES` (Android 13+)
- `READ_MEDIA_VIDEO` (Android 13+)
- `READ_MEDIA_AUDIO` (Android 13+)

These are automatically configured when using the Expo plugin.

## Local Testing

To test the package locally before publishing:

1. **Create a package:**
   ```bash
   npm pack
   ```

2. **In your test project, install from local file:**
   ```bash
   npm install /path/to/ethora-chat-component-1.0.0.tgz
   ```

3. **For Expo projects:**
   ```bash
   # Add plugin to app.json
   # Then run:
   npx expo prebuild
   npx expo run:ios  # or npx expo run:android
   ```

4. **For React Native CLI:**
   ```bash
   # iOS
   cd ios && pod install && cd ..
   npm run ios
   
   # Android
   npm run android
   ```

## Troubleshooting

### Expo: "Module not found" errors

Make sure you're using Expo Dev Client, not Expo Go:

```bash
npx expo install expo-dev-client
npx expo prebuild
npx expo run:ios  # or android
```

### TypeScript errors

Make sure TypeScript can resolve the types:

```json
// tsconfig.json
{
  "compilerOptions": {
    "moduleResolution": "node",
    "allowSyntheticDefaultImports": true
  }
}
```

### Metro bundler errors

Clear Metro cache:

```bash
npx react-native start --reset-cache
```

## License

AGPL

## Support

- [GitHub Issues](https://github.com/ethora/ethora-chat-component-rn/issues)
- [Documentation](https://github.com/ethora/ethora-chat-component-rn#readme)
